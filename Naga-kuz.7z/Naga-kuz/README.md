# botst4rz
BOT WHATSAPP HP BINTANG NUR PRADANA

### Alat dan Bahan
Siapin alat dan bahannya.
```bash
> niat
> 2 handphone (1 buat jalanin sc, 1 buat scan qr)
> internet yang memadai, kalo lu gapunya kuota pake kuota kemendikbud ae
> aplikasi whatsapp
> aplikasi termux
> kopi
```

### Cara Installnya
Sebelum lu jalanin sc nya install dulu lah.
```bash
> kalo lu belum punya apk termux, download di playstore
> masuk ke apk termux lalu ketik dibawah ini!
> git clone https://github.com/Bintang73/botst4rz.git
> cd botst4rz
> bash install.sh
> node index.js
> Tinggal scan qr dah
```

## Features

| st4rz BOT       |                Feature           |
| :-----------: | :--------------------------------: |
|       ✅       | Sticker Creator                  |
|       ✅       | Magernulis                       |
|       ✅       | Pantun                           |
|       ✅       | Youtube Downloader               |
|       ✅       | Quotes                           |
|       ✅       | Anime                            |
|       ✅       | Suara Google                     |
|       ✅       | Quran                            |
|       ✅       | Youtube MP3 Downloader           |
|       ✅       | Intagram Downloader              |
|       ✅       | Twitter Downloader               |
|       ✅       | Facebook Downloader              |
|       ✅       | Wikipedia                        |
|       ✅       | Say                              |
|       ✅       | Info                             |
|       ✅       | Donate                           |

## Special Thanks to
* [`termux-whatsapp-bot`](https://github.com/fdciabdul/termux-whatsapp-bot)

### Donate
* [`Saweria`](https://saweria.co/donate/bintangnurpradana)
